import './App.css';

function App() {
  return (
    <>
      <section className='bg-body flex'>
        <div className="sidebar h-full w-260 bg-sidebar p-2 relative">
          <div className="sidebar-top flex">

            {/* CHAT BTN */}
            <div className="chatBtn w-full ">
              <a className="flex px-3 min-h-[44px] py-1 items-center gap-3 transition-colors duration-200 dark:text-white cursor-pointer text-sm rounded-md border dark:border-white/20 gizmo:min-h-0 hover:bg-gray-500/10 h-11 gizmo:h-10 gizmo:rounded-lg gizmo:border-[rgba(0,0,0,0.1)] bg-white dark:bg-transparent "><i className="fa-solid fa-plus"></i><span className="truncate">New Chat</span></a>
            </div>

            {/*  CLOSE BTN */}
            <div className="flex justify-center items-center close-btn w-44 ms-2 px-4 min-h-[44px] py-1  transition-colors duration-200 dark:text-white cursor-pointer text-sm rounded-md border dark:border-white/20 gizmo:min-h-0 hover:bg-gray-500/10 h-11 gizmo:h-10 gizmo:rounded-lg gizmo:border-[rgba(0,0,0,0.1)] bg-white dark:bg-transparent flex-grow overflow-hidden">
              <a className=""><svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" className="icon-sm" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg></a>
            </div>
          </div>

          {/* SIDEBAR BOTTOM */}
          <div className="sidebar-bottom w-260 absolute left-0 pt-8 ">

            {/* UPGRADE TO PLUS */}
            <div className="flex px-3 min-h-[44px] py-1 items-center gap-3 transition-colors duration-200 dark:text-white cursor-pointer text-sm rounded-md gizmo:min-h-0 hover:bg-gray-500/10 h-11 gizmo:h-10 gizmo:rounded-lg bg-white dark:bg-transparent "><i className="fa-regular fa-user"></i><span className="truncate">Upgrade to Plus</span>
            </div>

            {/*  PROFILE */}
            <div className="flex w-full px-3 min-h-[44px] py-1 items-center gap-3 transition-colors duration-200 dark:text-white cursor-pointer text-sm rounded-md gizmo:min-h-0 hover:bg-gray-500/10 h-11 gizmo:h-10 gizmo:rounded-lg bg-white dark:bg-transparent ">
              <img src="/Images/profile.webp" alt="" />
              <h3 className="truncate fw-bold">Heet Morker</h3>
              <i className="ms-auto me-2 text-gray-400 fa-solid fa-ellipsis"></i>
            </div>

          </div>

        </div>
        <section className='own-w flex flex-col items-center justify-between'>
          <div className="content gpt-p ">
            <ul className="flex  justify-center items-center">
              <li className=' bg-gray-100 p-1 text-gray-900 dark:bg-gray-900'>
                <button className=" flex items-center justify-center gap-1 rounded-lg border py-3 outline-none  duration-100 sm:w-auto sm:min-w-[148px]  md:gap-2 md:py-2.5 border-black/10 bg-white text-gray-900 shadow-[0_1px_7px_0px_rgba(0,0,0,0.06)] hover:!opacity-100 dark:border-[#4E4F60] dark:bg-gray-700 dark:text-gray-100">
                  <span className="max-[370px]:hidden relative"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="green" className="icon-sm transition-colors text-brand-green" width="16" height="16"><path d="M9.586 1.526A.6.6 0 0 0 8.553 1l-6.8 7.6a.6.6 0 0 0 .447 1h5.258l-1.044 4.874A.6.6 0 0 0 7.447 15l6.8-7.6a.6.6 0 0 0-.447-1H8.542l1.044-4.874Z" fill="currentColor"></path></svg></span><span className="truncate text-sm font-medium md:pr-1.5 pr-1.5">GPT-3.5</span>
                </button>
              </li>
              <li className='bg-gray-100 p-1  text-gray-900 dark:bg-gray-900'><button className="w-full cursor-pointer">
                <div className=" flex w-full items-center justify-center gap-1 rounded-lg border py-3 outline-none transition-opacity duration-100 sm:w-auto sm:min-w-[148px] md:gap-2 md:py-2.5 border-transparent text-gray-500 hover:text-gray-800 hover:dark:text-gray-100"><span className="max-[370px]:hidden relative"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" className="icon-sm transition-colors group-hover/button:text-brand-purple" width="16" height="16"><path d="M12.784 1.442a.8.8 0 0 0-1.569 0l-.191.953a.8.8 0 0 1-.628.628l-.953.19a.8.8 0 0 0 0 1.57l.953.19a.8.8 0 0 1 .628.629l.19.953a.8.8 0 0 0 1.57 0l.19-.953a.8.8 0 0 1 .629-.628l.953-.19a.8.8 0 0 0 0-1.57l-.953-.19a.8.8 0 0 1-.628-.629l-.19-.953h-.002ZM5.559 4.546a.8.8 0 0 0-1.519 0l-.546 1.64a.8.8 0 0 1-.507.507l-1.64.546a.8.8 0 0 0 0 1.519l1.64.547a.8.8 0 0 1 .507.505l.546 1.641a.8.8 0 0 0 1.519 0l.546-1.64a.8.8 0 0 1 .506-.507l1.641-.546a.8.8 0 0 0 0-1.519l-1.64-.546a.8.8 0 0 1-.507-.506L5.56 4.546Zm5.6 6.4a.8.8 0 0 0-1.519 0l-.147.44a.8.8 0 0 1-.505.507l-.441.146a.8.8 0 0 0 0 1.519l.44.146a.8.8 0 0 1 .507.506l.146.441a.8.8 0 0 0 1.519 0l.147-.44a.8.8 0 0 1 .506-.507l.44-.146a.8.8 0 0 0 0-1.519l-.44-.147a.8.8 0 0 1-.507-.505l-.146-.441Z" fill="currentColor"></path></svg></span><span className="truncate text-sm font-medium md:pr-1.5 pr-1.5">GPT-4</span></div></button>
              </li>
            </ul>
          </div>
          <div className="chat-main h-full large-w">
            <div className="question">
              <div className="profile rounded-sm" >
                <img src="/Images/profile.webp" alt="" class="img-fluid" />
              </div>
              <div class="main-question">
                
              </div>
            </div>
          </div>
          <div className="chat-footer flex justify-center items-center ">
            <div className="chat relative">
              {/* MAIN SEARCHBAR */}
              <div className="main-searchbar">
              <input type="text" name="" id="" placeholder='Send a message'  className='border-0 rounded-xl focus:ring-0 focus-visible:ring-0 dark:bg-transparent gizmo:placeholder-black/50 gizmo:dark:placeholder-white/50'/>

              </div>
              <div className="send" >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="icon-sm m-1 md:m-0"><path d="M.5 1.163A1 1 0 0 1 1.97.28l12.868 6.837a1 1 0 0 1 0 1.766L1.969 15.72A1 1 0 0 1 .5 14.836V10.33a1 1 0 0 1 .816-.983L8.5 8 1.316 6.653A1 1 0 0 1 .5 5.67V1.163Z" fill="currentColor" ></path></svg>
              </div>
              <p className='relative px-2 py-2 text-center text-xs text-gray-600 dark:text-gray-300 '>Free Research Preview. ChatGPT may produce inaccurate information about people, places, or facts. ChatGPT September 25 Version</p>
            </div>
          </div>
        </section>
      </section>
    </>
  );
}

export default App;
